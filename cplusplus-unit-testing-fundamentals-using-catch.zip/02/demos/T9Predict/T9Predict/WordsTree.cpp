#include "WordsTree.h"



WordsTree::WordsTree()
{
}


WordsTree::~WordsTree()
{
}

void WordsTree::AddWord(const std::string& word)
{
}

bool WordsTree::DoesWordExist(const std::string word) const
{
	return false;
}
